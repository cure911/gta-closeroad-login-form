function StageTwo() {
    document.getElementsByClassName("panel")[0].style.display = "none";
    document.body.style.backgroundColor = "white";
    document.getElementsByClassName("main-side")[0].style.display = "block";
}